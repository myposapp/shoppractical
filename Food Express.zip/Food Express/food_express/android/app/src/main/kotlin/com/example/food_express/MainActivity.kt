package com.example.food_express

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
